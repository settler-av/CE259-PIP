from django.apps import AppConfig


class EmailattachmentConfig(AppConfig):
    name = 'emailattachment'
